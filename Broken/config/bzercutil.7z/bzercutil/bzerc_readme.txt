Bzerc Utility-Belt
Version 1.25
By Jabbapop (n64q2@aol.com)


Reason for new version-
1. Grrr. Forgot to add lead target toggle.
2. Also a minor, harmless bug.

Requirements-
1. Battlezone 2
2. To use the multiworld options in Misc section, must have one of the recent 1.2 beta    builds.

Installation-

1. Make sure you unzipped with directories intact.
2. Uninstall any older versions of BZERC.
2. Copy and paste the folder called "bzercutil" to your addon directory.


What it does-
Many features!! Try it out!!! 
1. You can change password IN GAME!!! 
2. Change amount of players allowed in game IN GAME!!!
3. Change allowable vehicles IN GAME!!!
4. Many others! Just try it!

How To Use-
Click on any of the catagories. Everything should be pretty self explanatory.
SpawnVehicle in the client tab is to change your vehicle that you respawn in in fixed vehicle dm games. If the 3d model in the vehicle window doesn't change, that means the host didn't allow that vehicle that is currently selected in the listbox.

Notes-
	Only the host should use the options under the host tab. If the client does, abnormalaties may occur!

	Also, changing available vehicles in game does not effect the players in the game. It only effects players that are still in shell or about to join.

	When a new player joins, some of the settings may be set back again, such as visibility. Sorry, there's nothing I can do about this.

	Sometimes wireframe mode only works correctly with terrain detail on medium or high.




Mail bugs to n64q2@aol.com
BzercPage at:
http://www.crosswinds.net/~bzcg/