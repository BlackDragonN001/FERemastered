#ifndef _SubMission_
#define _SubMission_

#include "..\..\source\fun3d\ScriptUtils.h"

#define MAX_TEAMS 16

class SubMission {
public:
	SubMission(void)
	{
		b_array = NULL;
		b_count = 0;

		f_array = NULL;
		f_count = 0;

		h_array = NULL;
		h_count = 0;

		i_array = NULL;
		i_count = 0;	
	}

	virtual void Setup(void) = 0;
	virtual void Execute(bool *TeamIsSetUp, Handle *RecyclerHandles) = 0;

	virtual void AddObject(Handle h)
	{
	}
	virtual void DeleteObject(Handle h)
	{
	}
	virtual void ProcessCommand(unsigned long crc)
	{
	}

	bool Save(bool missionSave);
	bool Load(bool missionSave);
	bool PostLoad(bool missionSave);

	bool *b_array;
	int b_count;

	float *f_array;
	int f_count;

	int *h_array;
	int h_count;

	int *i_array;
	int i_count;
};

extern SubMission *BuildSubMission(void);

#endif
