BZII Community Project beta multiplayer DLLs
by BS-er

DMCP01.dll - Multiplayer Deathmatch
MPICP01.dll - Multi-instant
StratCP01.DLL - Multiplayer Strategy

The following applies to all 3 DLLs:
____________________________________________________________________
Label portals as follows (case-sensitive):
PortalA0, PortalA1, PortalA2 ...
PortalB0, PortalB1 ...

You can have up to 6 portal groups: A, B, C, D, E, F
A group can have up to 10 portals (0 thru 9).
Portals in each group are linked numerically in a daisy-chain fashion, i.e. PortalA0 sends to PortalA1, and PortalA1 sends to PortalA2.  The highest numbered portal in the group sends back to PortalA0.

There can be no more than 16 portals total on a map.

A portal on team 0 will teleport any unit.  A portal on team 1 or higher will only teleport units on its own team, or are allies.


The following applies to the MPI DLL only:
____________________________________________________________________
To designate an AI team's ODF type that you want to send to a specific portal, label an object of the desired type as PortalUser0, PortalUser1 etc. (case-sensitive).  Place that object next to the portal that you want it to use.  For example, if you want all scouts on the AI team to go through a portal, Label an ivscout or fvscout as PortalUser0, and put it next to the portal that it is to use. The first letter of the ODF name doesn't matter.  As long as the rest of the letters in the ODF name match, the DLL will send those ODF types on the enemy team to the designated portal.  The objects that are placed will be deleted at game time.  The team of the objects doesn't matter (team 0 is fine, since they will be deleted anyway if labelled properly).

Only 1 portal per ODF type (may change in future release). Use each label only once (PortalUser0 thru PortalUser9).

Units exit the destination portal on the opposite side from where they entered.  Therefore you should put some entry portals BEHIND the AI base if those units are to exit on the opposite side of the player's base.

For ISDF/Scion combat, the same AIP names are used as in BZII.  The following are the naming conventions for AIP sets that involve Hadeans (substitute the AIP type designator [0, 1, 2 etc.] for the *).
Hadean AI vs Scion human:  hadeinsts*.aip
Hadean AI vs. Hadean human:  hadeinst_*.aip
Hadean AI vs. EDF human:  hadeinsti*.aip
EDF AI vs. Hadean human:  isdfinsth*.aip
Scion vs. Hadean human:	 scioninsth*.aip

For custom AIP names, simply use 'h' for Hadean in the same manner as you would use 'i' for ISDF and 's' for Scion.