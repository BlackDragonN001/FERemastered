Notes on Battlezone 2 v1.2 MP DLL Source code.

   Disclaimer: this source code release is UNSUPPORTED by Activision,
Pandemic Studios, and the like. While it is a complete archive of an
functional multiplayer DLL source code and MS Visual C++ 6.x project,
it comes with no warranty, no official support, or anything else.

   Included in this archive is a complete set of source code needed to
build Battlezone 2's Deathmatch DLL for version 1.2. Inside the
Missions/Deathmatch01 folder, there is a Deathmatch01.dsw project file
for MS Visual C++ (aka MSVC). Opening this project in that environment
will let you build up a DLL to the Debug/Missions folder off the root
of this archive. Similarly, the Missions/Strategy02 and
Missions/MPInstant folders contain source code for the other DLLs.

   Comments on multiplayer programming: because BZ2 runs in a lockstep
fashion, every DLL running on all of the machines must behave
identically in terms of anything that affects gamestate. Thus, do not
do anything based on the local player, but if you're doing something,
loop over all players, e.g. a loop like

for(int CheckTeam=0;CheckTeam<MAX_TEAMS;CheckTeam++) {
	Handle h=GetPlayerHandle(CheckTeam);
	if(h) { // Player Exists...
		// .. Do stuff here....
	}
}

   Only visual-only things like objectifying targets (see the
ExecuteRace() function) can be done not identically across platforms.


