#ifndef _TAUNTS_H_
#define _TAUNTS_H_

enum TauntTypes {
	TAUNTS_GameStart,
	TAUNTS_NewHuman,
	TAUNTS_LeftHuman,
	TAUNTS_HumanShipDestroyed,
	TAUNTS_HumanRecyDestroyed,
	TAUNTS_CPURecyDestroyed,
	TAUNTS_Random,
	TAUNTS_MAX,
};

// Required setup call before you call DoTaunt(). GameTime is used to
// squelch too-often messages. [It should be the # of calls to
// Execute].  LastMessagePrintedAt is a scratchpad variable used to
// note things. aCPUTeamName is an override for that name; if
// specified, it won't query network.session.svar2 for it.
void InitTaunts(int *GameTimePtr, int *LastMessagePrintedAt,const char *aCPUTeamName = NULL);

// Prints a taunt from the specified category. 
void DoTaunt(TauntTypes Taunt);

#endif // _TAUNTS_H_
